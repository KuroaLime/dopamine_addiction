// Fill out your copyright notice in the Description page of Project Settings.


#include "Game/InGame/Card/Actor/CoinRegulator.h"
#include "Game/InGame/Card/Actor/WG_HavingCoin.h"
#include "Default/Data/CharacterStateComponent.h"
#include "Components/WidgetComponent.h"

#include "Kismet/GameplayStatics.h"
#include "Game/InGame/ManagerCharacter.h"
// Sets default values
ACoinRegulator::ACoinRegulator()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	Body = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BODY"));

	RootComponent = Body;

	HavingCoin = CreateDefaultSubobject<UWidgetComponent>(TEXT("HPBARWIDGET"));
	HavingCoin->SetupAttachment(RootComponent);
	HavingCoin->SetRelativeLocation(FVector(0.0f, 0.0f, 180.0f));
	HavingCoin->SetWidgetSpace(EWidgetSpace::World);
	HavingCoin->SetDrawAtDesiredSize(true);
	HavingCoin->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	HavingCoin->SetOwnerNoSee(false);
}

// Called when the game starts or when spawned
void ACoinRegulator::BeginPlay()
{
	if (CoinWidgetClass)
	{
		HavingCoin->SetWidgetClass(CoinWidgetClass);
	}

	Super::BeginPlay();
	
	if (!TargetPS)
	{
		ACharacter* MyCharacter = UGameplayStatics::GetPlayerCharacter(this, 0);

		if (AManagerCharacter* ManagerChar = Cast<AManagerCharacter>(MyCharacter))
		{
			TargetPS = ManagerChar->CharacterState;
		}
	}

	auto CharacterWidget = Cast<UWG_HavingCoin>(HavingCoin->GetUserWidgetObject());

	if (nullptr != CharacterWidget && nullptr != TargetPS)
	{
		//if(AMainPlayerState* PS = Cast<AMainPlayerState>(HavingCoin->GetUserWidgetObject()))
		CharacterWidget->BindCharacterState(TargetPS);
	}

}

// Called every frame
void ACoinRegulator::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}






