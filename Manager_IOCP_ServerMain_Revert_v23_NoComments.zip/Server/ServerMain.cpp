// ServerMain.cpp
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <string>
#include <thread>
#include <vector>

#include "Protocol_D.h"
#include "NetApi.h"
#include "LobbyService.h"

// ===========================================================================
// ������ ���
// ===========================================================================
const char* PacketTypeToString(uint16_t type) {
    switch (static_cast<PacketType>(type)) {
    case PacketType::C2S_PING:            return "C2S_PING";
    case PacketType::S2C_PONG:            return "S2C_PONG";
    case PacketType::S2C_WELCOME:         return "S2C_WELCOME";

    case PacketType::C2S_LOGIN_REQ:       return "C2S_LOGIN_REQ";
    case PacketType::S2C_LOGIN_RES:       return "S2C_LOGIN_RES";
    case PacketType::C2S_REGISTER_REQ:    return "C2S_REGISTER_REQ";
    case PacketType::S2C_REGISTER_RES:    return "S2C_REGISTER_RES";

    case PacketType::C2S_ROOM_LIST_REQ:   return "C2S_ROOM_LIST_REQ";
    case PacketType::S2C_ROOM_LIST_RES:   return "S2C_ROOM_LIST_RES";

    case PacketType::C2S_ROOM_CREATE_REQ: return "C2S_ROOM_CREATE_REQ";
    case PacketType::S2C_ROOM_CREATE_RES: return "S2C_ROOM_CREATE_RES";

    case PacketType::C2S_ROOM_JOIN_REQ:   return "C2S_ROOM_JOIN_REQ";
    case PacketType::S2C_ROOM_JOIN_RES:   return "S2C_ROOM_JOIN_RES";

    case PacketType::C2S_ROOM_LEAVE_REQ:  return "C2S_ROOM_LEAVE_REQ";
    case PacketType::S2C_ROOM_LEAVE_RES:  return "S2C_ROOM_LEAVE_RES";

    case PacketType::C2S_ROOM_READY_REQ:  return "C2S_ROOM_READY_REQ";
    case PacketType::S2C_ROOM_READY_BRD:  return "S2C_ROOM_READY_BRD";

    case PacketType::C2S_ROOM_START_REQ:  return "C2S_ROOM_START_REQ";
    case PacketType::S2C_ROOM_START_RES:  return "S2C_ROOM_START_RES";

    case PacketType::S2C_GAME_START:      return "S2C_GAME_START";
    default:                              return "UNKNOWN_PACKET";
    }
}

// ===========================================================================
// ���� ���� �� ����
// ===========================================================================
static const char* LISTEN_IP = "0.0.0.0";
static const uint16_t LISTEN_PORT = 9000;
static const int RECV_BUF_SIZE = 4096;

static HANDLE g_iocp = NULL;
static SOCKET g_listenSock = INVALID_SOCKET;
static std::atomic<bool> g_running{ true };

enum class IOType : uint8_t { RECV, SEND };

// ===========================================================================
// ������ ����ü
// ===========================================================================
struct PerIoContext {
    OVERLAPPED ol{};
    WSABUF wsaBuf{};
    IOType type = IOType::RECV;
    char buffer[RECV_BUF_SIZE]{};

    // Send�� ����
    std::vector<char> dynBuffer;
    size_t dynOffset = 0;

    void ResetRecv() {
        std::memset(&ol, 0, sizeof(ol));
        type = IOType::RECV;
        wsaBuf.buf = buffer;
        wsaBuf.len = RECV_BUF_SIZE;
    }
};

struct ClientContext {
    SOCKET sock = INVALID_SOCKET;
    sockaddr_in addr{};

    PerIoContext recvCtx;
    std::atomic<long> ioRef{ 0 };
    std::atomic<bool> closing{ false };

    // ���� ���� ���� (TCP ��� ó����)
    std::vector<char> streamBuf;

    // �۽� ť
    SRWLOCK sendLock{};
    std::deque<std::vector<char>> sendQueue;
    bool sendInFlight = false;

    ClientContext(SOCKET s, const sockaddr_in& a) : sock(s), addr(a) {
        recvCtx.ResetRecv();
        streamBuf.reserve(8192);
        InitializeSRWLock(&sendLock);
    }
};

// ===========================================================================
// �۷ι� ��ü �� ���� �Լ�
// ===========================================================================
void SendPacket(ClientContext* c, uint16_t type, const void* payload, uint16_t payloadLen);

NetApi       g_net(SendPacket);
LobbyService g_lobby(g_net);

void AddIO(ClientContext* c) {
    c->ioRef.fetch_add(1, std::memory_order_relaxed);
}

void ReleaseIO(ClientContext* c) {
    const long left = c->ioRef.fetch_sub(1, std::memory_order_acq_rel) - 1;
    if (left == 0 && c->closing.load(std::memory_order_acquire)) {
        closesocket(c->sock);
        delete c;
    }
}

// ===========================================================================
// �۽� ����
// ===========================================================================
void SendPacket(ClientContext* c, uint16_t type, const void* payload, uint16_t payloadLen) {
    const uint16_t totalSize = static_cast<uint16_t>(sizeof(PacketHeader) + payloadLen);
    if (totalSize > PACKET_SIZE_MAX) return;

    std::vector<char> pkt(totalSize);
    PacketHeader hdr{};
    hdr.size = htons(totalSize);
    hdr.type = htons(type);

    std::memcpy(pkt.data(), &hdr, sizeof(hdr));
    if (payloadLen > 0 && payload) {
        std::memcpy(pkt.data() + sizeof(hdr), payload, payloadLen);
    }

    // ������ ���
    printf("[SEND] to=%d.%d.%d.%d type=%s(%u) payloadLen=%u totalSize=%u\n",
        c->addr.sin_addr.S_un.S_un_b.s_b1,
        c->addr.sin_addr.S_un.S_un_b.s_b2,
        c->addr.sin_addr.S_un.S_un_b.s_b3,
        c->addr.sin_addr.S_un.S_un_b.s_b4,
        PacketTypeToString(type),
        type,
        payloadLen,
        totalSize);

    AcquireSRWLockExclusive(&c->sendLock);
    c->sendQueue.push_back(std::move(pkt));

    // ���� ���� ���� Send�� ���ٸ� �ٷ� ����
    if (!c->sendInFlight) {
        c->sendInFlight = true;

        PerIoContext* sendCtx = new PerIoContext();
        sendCtx->type = IOType::SEND;
        sendCtx->dynBuffer = c->sendQueue.front();
        sendCtx->wsaBuf.buf = sendCtx->dynBuffer.data();
        sendCtx->wsaBuf.len = (ULONG)sendCtx->dynBuffer.size();

        AddIO(c);
        DWORD flags = 0;
        if (WSASend(c->sock, &sendCtx->wsaBuf, 1, NULL, flags, &sendCtx->ol, NULL) == SOCKET_ERROR) {
            int err = WSAGetLastError();
            if (err != WSA_IO_PENDING) {
                printf("[SEND-ERR] to=%d.%d.%d.%d type=%s(%u) WSA=%d\n",
                    c->addr.sin_addr.S_un.S_un_b.s_b1,
                    c->addr.sin_addr.S_un.S_un_b.s_b2,
                    c->addr.sin_addr.S_un.S_un_b.s_b3,
                    c->addr.sin_addr.S_un.S_un_b.s_b4,
                    PacketTypeToString(type),
                    type,
                    err);

                ReleaseIO(c);
                delete sendCtx;
                c->sendInFlight = false;
            }
        }
    }
    ReleaseSRWLockExclusive(&c->sendLock);
}

// ===========================================================================
// Worker Thread
// ===========================================================================
void WorkerThread() {
    while (g_running.load()) {
        DWORD bytesTransferred = 0;
        ULONG_PTR completionKey = 0;
        LPOVERLAPPED overlapped = nullptr;

        BOOL ret = GetQueuedCompletionStatus(g_iocp, &bytesTransferred, &completionKey, &overlapped, INFINITE);

        if (!ret && overlapped == nullptr) continue;

        ClientContext* client = reinterpret_cast<ClientContext*>(completionKey);
        PerIoContext* ioCtx = CONTAINING_RECORD(overlapped, PerIoContext, ol);

        // [���� �� ���� ó��]
        if (!ret || (bytesTransferred == 0 && ioCtx->type == IOType::RECV)) {
            if (!client->closing.exchange(true)) {
                g_lobby.OnClientDisconnected(client);
                closesocket(client->sock);
            }
            ReleaseIO(client);
            if (ioCtx->type == IOType::SEND) delete ioCtx;
            continue;
        }

        // [���� ó��]
        if (ioCtx->type == IOType::RECV) {
            bool closeClient = false;

            // 1. ���� �����͸� streamBuf�� ����
            client->streamBuf.insert(client->streamBuf.end(), ioCtx->buffer, ioCtx->buffer + bytesTransferred);

            // 2. ��Ŷ ���(4����Ʈ)�� ���� �� ���� ��ŭ �����Ͱ� �׿����� Ȯ��
            while (client->streamBuf.size() >= sizeof(PacketHeader)) {
                PacketHeader hdr;
                std::memcpy(&hdr, client->streamBuf.data(), sizeof(PacketHeader));

                uint16_t totalSize = ntohs(hdr.size);
                uint16_t type = ntohs(hdr.type);

                // ��� ����
                if (totalSize < sizeof(PacketHeader) || totalSize > PACKET_SIZE_MAX) {
                    if (!client->closing.exchange(true)) {
                        g_lobby.OnClientDisconnected(client);
                        closesocket(client->sock);
                    }
                    closeClient = true;
                    break;
                }

                // 3. �ϳ��� ������ ��Ŷ�� �� ���Դٸ�?
                if (client->streamBuf.size() >= totalSize) {
                    uint16_t payloadLen = totalSize - static_cast<uint16_t>(sizeof(PacketHeader));
                    const char* payload = client->streamBuf.data() + sizeof(PacketHeader);

                    printf("[RECV] from=%d.%d.%d.%d type=%s(%u) payloadLen=%u totalSize=%u\n",
                        client->addr.sin_addr.S_un.S_un_b.s_b1,
                        client->addr.sin_addr.S_un.S_un_b.s_b2,
                        client->addr.sin_addr.S_un.S_un_b.s_b3,
                        client->addr.sin_addr.S_un.S_un_b.s_b4,
                        PacketTypeToString(type),
                        type,
                        payloadLen,
                        totalSize);

                    g_lobby.OnPacket(client, type, payload, payloadLen);

                    client->streamBuf.erase(client->streamBuf.begin(),
                        client->streamBuf.begin() + totalSize);
                }
                else {
                    // ��Ŷ�� ���� �� ������ ���� Ż���ؼ� �� ����
                    break;
                }
            }

            // ������ ����� Ŭ�� �ݾƾ� �ϸ�, ���� I/O�� �����ϰ� ���� GQCS�� �Ѿ
            if (closeClient) {
                ReleaseIO(client);
                continue;
            }

            // 4. ���� �����͸� �ޱ� ���� �ٽ� Recv ��û
            ioCtx->ResetRecv();
            DWORD flags = 0;
            if (WSARecv(client->sock, &ioCtx->wsaBuf, 1, NULL, &flags, &ioCtx->ol, NULL) == SOCKET_ERROR) {
                if (WSAGetLastError() != WSA_IO_PENDING) {
                    if (!client->closing.exchange(true)) {
                        g_lobby.OnClientDisconnected(client);
                        closesocket(client->sock);
                    }
                    ReleaseIO(client);
                }
            }
        }
        // [�۽� ó��]
        else if (ioCtx->type == IOType::SEND) {
            ioCtx->dynOffset += bytesTransferred;

            // ���� �� ���� �����Ͱ� �ִٸ� (�κ� ���� �߻�)
            if (ioCtx->dynOffset < ioCtx->dynBuffer.size()) {
                ioCtx->wsaBuf.buf = ioCtx->dynBuffer.data() + ioCtx->dynOffset;
                ioCtx->wsaBuf.len = (ULONG)(ioCtx->dynBuffer.size() - ioCtx->dynOffset);

                DWORD flags = 0;
                if (WSASend(client->sock, &ioCtx->wsaBuf, 1, NULL, flags, &ioCtx->ol, NULL) == SOCKET_ERROR) {
                    if (WSAGetLastError() != WSA_IO_PENDING) {
                        ReleaseIO(client);
                        delete ioCtx;
                        AcquireSRWLockExclusive(&client->sendLock);
                        client->sendInFlight = false;
                        ReleaseSRWLockExclusive(&client->sendLock);
                    }
                }
            }
            // �� ���´ٸ� ť���� ���� ��Ŷ Ȯ��
            else {
                delete ioCtx;

                AcquireSRWLockExclusive(&client->sendLock);
                client->sendQueue.pop_front();

                if (!client->sendQueue.empty()) {
                    PerIoContext* nextSend = new PerIoContext();
                    nextSend->type = IOType::SEND;
                    nextSend->dynBuffer = client->sendQueue.front();
                    nextSend->wsaBuf.buf = nextSend->dynBuffer.data();
                    nextSend->wsaBuf.len = (ULONG)nextSend->dynBuffer.size();

                    DWORD flags = 0;
                    if (WSASend(client->sock, &nextSend->wsaBuf, 1, NULL, flags, &nextSend->ol, NULL) == SOCKET_ERROR) {
                        if (WSAGetLastError() != WSA_IO_PENDING) {
                            ReleaseIO(client);
                            delete nextSend;
                            client->sendInFlight = false;
                        }
                    }
                }
                else {
                    client->sendInFlight = false;
                    ReleaseIO(client);
                }
                ReleaseSRWLockExclusive(&client->sendLock);
            }
        }
    }
}

// ===========================================================================
// Main Entry Point
// ===========================================================================
int main() {
    WSADATA wsa{};
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return 1;

    g_iocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);
    if (!g_iocp) return 1;

    // ��Ŀ ������ 4�� ����
    std::vector<std::thread> workers;
    for (int i = 0; i < 4; ++i) workers.emplace_back(WorkerThread);

    g_listenSock = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(LISTEN_PORT);
    inet_pton(AF_INET, LISTEN_IP, &serverAddr.sin_addr);

    bind(g_listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr));
    listen(g_listenSock, SOMAXCONN);

    printf("[Server] Listening on %s:%d...\n", LISTEN_IP, LISTEN_PORT);

    // Accept ����
    while (g_running.load()) {
        sockaddr_in clientAddr{};
        int addrLen = sizeof(clientAddr);

        SOCKET clientSock = WSAAccept(g_listenSock, (sockaddr*)&clientAddr, &addrLen, NULL, 0);
        if (clientSock == INVALID_SOCKET) {
            Sleep(10);
            continue;
        }

        printf("[Server] Client Accepted: %d.%d.%d.%d\n",
            clientAddr.sin_addr.S_un.S_un_b.s_b1, clientAddr.sin_addr.S_un.S_un_b.s_b2,
            clientAddr.sin_addr.S_un.S_un_b.s_b3, clientAddr.sin_addr.S_un.S_un_b.s_b4);

        ClientContext* ctx = new ClientContext(clientSock, clientAddr);
        AddIO(ctx);

        CreateIoCompletionPort((HANDLE)clientSock, g_iocp, (ULONG_PTR)ctx, 0);

        AddIO(ctx);
        DWORD flags = 0;
        if (WSARecv(clientSock, &ctx->recvCtx.wsaBuf, 1, NULL, &flags, &ctx->recvCtx.ol, NULL) == SOCKET_ERROR) {
            if (WSAGetLastError() != WSA_IO_PENDING) {
                ReleaseIO(ctx);
                ReleaseIO(ctx);
                delete ctx;
                continue;
            }
        }

        g_lobby.OnClientAccepted(ctx);
    }

    g_running = false;
    for (auto& t : workers) if (t.joinable()) t.join();

    closesocket(g_listenSock);
    CloseHandle(g_iocp);
    WSACleanup();

    return 0;
}